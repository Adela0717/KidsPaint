import java.util.ArrayList;
import java.util.List;

public class KidPaint {
	public static void main(String[] args) {
		
		User user = new User();
		
//		List<String> studios = new ArrayList<String>();
//  		studios.add("test1");
//		studios.add("test2");
//		
//		
//		groupUI ui = new groupUI(studios);			// get the instance of UI
//		ui.setVisible(true);
//		
		//ui.setData(new int[50][50], 20);	// set the data array and block size. comment this statement to use the default data array and block size.
		//ui.setVisible(true);				// set the ui
		
		
	}
}
