

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
public class Client {
	UI ui;
	groupUI gui;
	Boolean runFlag = true;
	String Server_tcpIp = "";
	int Server_tcpPort ;
	Socket socket = null;
	ObjectOutputStream objOutputStream = null;
	public Client(UI ui) {
		super();
		this.ui = ui;
		
	}

	public void getIpAndPort() throws IOException {
		//1.��������
		 //�������ݱ��׽��ֲ�����󶨵�����������4002�˿ڡ�
		 DatagramSocket dsocket = new DatagramSocket(4002);
		 //2.���
		 byte[] arr = "request".getBytes();
		 //�ĸ�����: �������� ���ĳ��� �������� �˿ں�   
		 DatagramPacket packet = new DatagramPacket
		  (arr, arr.length,InetAddress.getByName(getLocalIpAddress()) , 4000);
		  
		 //3.����
		 dsocket.send(packet);
		 
		 //4.receive UDP from Server
		 byte[] buf =new byte[1024];
		 DatagramPacket packetr = new DatagramPacket(buf, buf.length);
		 try {
			 dsocket.receive(packetr);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 buf = packetr.getData(); 
		 System.out.println(new String(buf));
		 Server_tcpIp = new String(buf).split(",")[0];
		 Server_tcpPort = Integer.parseInt(new String(buf).split(",")[1]);
		 //4.�ر���Դ
		 dsocket.close();
	}
	
	private String getLocalIpAddress() {
        try {
            Enumeration en = NetworkInterface.getNetworkInterfaces();
            for (; en.hasMoreElements(); ) {
                NetworkInterface intf = (NetworkInterface) en.nextElement();
                for (Enumeration enumIpAddr = intf.getInetAddresses(); 
                         enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && 
                           !inetAddress.isLinkLocalAddress()) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (SocketException ex) {
 
        }
        return null;
    }
	//if the client decide to set up TCP connection with this server, run this
    public void start() {
    	System.out.println("Connecting to Server...");
		try {
			socket = new Socket(Server_tcpIp, Server_tcpPort);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objOutputStream = new ObjectOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Successfully connected to server");
		/*
		 * ������ȡ����˷��͹�������Ϣ���̡߳�
		 */
		
		ServerHandler handler = new ServerHandler();
		Thread t = new Thread(handler);
		t.start();
		
		
		}
    	
    public void send(Message m)  {
    	
    	try {
			objOutputStream.writeObject(m);
			//objOutputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
    
    
    //receive message from server
		class ServerHandler implements Runnable{
			public void run(){
				try {
					ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
					while(runFlag){
						Message m = (Message)objectInputStream.readObject();
						switch (m.getMt()) {
						case MESSAGE:
							ui.updateText(m.getContent());
							break;
						case DIFFERENTIAL:
							int[] a = m.getDifferentialFromContent();
							ui.updatePaintPixel(a[0], a[1],a[2]);
							break;
						case STUDIONAME:
							List<String> studioName = m.getContentFromList();
							gui.updateStudio(studioName);
							break;
						
				
						default:
						}
						
					}
				} catch (Exception e) {
					
				}finally {
					
				}
			}
		}
		
}